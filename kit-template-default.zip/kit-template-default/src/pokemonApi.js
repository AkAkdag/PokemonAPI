// pokemonApi.js
import axios from 'axios';

const BASE_URL = 'https://api.pokemontcg.io/v2';

export async function getAllPokemons() {
  try {
    const response = await axios.get(`${BASE_URL}/cards`);
    return response.data.data;
  } catch (error) {
    console.error('Fout bij het ophalen van Pokémon-kaarten:', error);
    throw error;
  }
}

export async function getPokemonDetails(id) {
  try {
    const response = await axios.get(`${BASE_URL}/cards/${id}`);
    return response.data.data;
  } catch (error) {
    console.error('Fout bij het ophalen van details voor Pokémon met ID:', id, error);
    throw error;
  }
}
