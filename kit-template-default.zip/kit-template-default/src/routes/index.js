// src/routes/index.js

import PokemonList from './PokemonList.svelte';
import PokemonDetails from './PokemonDetails.svelte';

export const routes = [
  {
    name: '/',
    component: PokemonList,
  },
  {
    name: 'pokemon-details',
    component: PokemonDetails,
  },
];
