<!-- <script>
	import Counter from './Counter.svelte';
	import welcome from '$lib/images/svelte-welcome.webp';
	import welcome_fallback from '$lib/images/svelte-welcome.png';
</script>

<svelte:head>
	<title>Home</title>
	<meta name="description" content="Svelte demo app" />
</svelte:head>

<section>
	<h1>
		<span class="welcome">
			<picture>
				<source srcset={welcome} type="image/webp" />
				<img src={welcome_fallback} alt="Welcome" />
			</picture>
		</span>

		to your new<br />SvelteKit app
	</h1>

	<h2>
		try editing <strong>src/routes/+page.svelte</strong>
	</h2>

	<Counter />
</section>

<style>
	section {
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		flex: 0.6;
	}

	h1 {
		width: 100%;
	}

	.welcome {
		display: block;
		position: relative;
		width: 100%;
		height: 0;
		padding: 0 0 calc(100% * 495 / 2048) 0;
	}

	.welcome img {
		position: absolute;
		width: 100%;
		height: 100%;
		top: 0;
		display: block;
	}
</style> -->
<!-- src/routes/PokemonDetails.svelte -->

<script>
	import { onMount } from 'svelte';
	import { getAllPokemons, getPokemonDetails } from '../pokemonApi';
  
	let pokemonId = '';
	/**
	 * @type {{ name: any; id: any; } | null}
	 */
	let pokemons = null;
	let loadingText = "Loading";
	let pokemonIDs = [];
	let pokemonDetail = null;
  
	const loadPokemons = async () => {
	  try {
		console.log('Fetching details for Pokemon ID:', pokemonId);
		// Roep de getPokemonDetails-functie aan om details van de geselecteerde Pokémon op te halen
		pokemons = await getAllPokemons();
		console.log('Received Pokemon details:', pokemons);
		pokemons.forEach(pokemon => {
			pokemonIDs.push(pokemon.id)
		});
	  } catch (error) {
		console.error('Fout bij het ophalen van Pokémon-details:', error);
	  }
	};

	const getPokemon = async () => {
		console.log("TEST")
		pokemonDetail = await getPokemonDetails(pokemonId)
	}
  
	onMount(() => {
	  // Roep getPokemon functie aan wanneer het component is gemount
	  loadPokemons();
	});
  </script>
  
  <main>
	<h1>Pokemon-details</h1>
	<label for="pokemonId">Voer Pokemon-ID in:</label>
	<input type="text" bind:value={pokemonId} id="pokemonId" />
	<button on:click={getPokemon}>Haal Pokemon-details op</button>
  
	{#if pokemons}
	  <div>
		<h2>{pokemonIDs}</h2>
		<!-- Voeg hier andere details toe -->
	  </div>
	{:else}
	  <p>{loadingText}</p>
	{/if}
	{#if pokemonDetail }
		<p>{pokemonDetail.name}</p>
	{/if}
  </main>
  
  <style>
	/* Voeg hier eventuele CSS-stijlen toe voor opmaak */
  </style>
  