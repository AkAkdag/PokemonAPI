<!-- src/routes/PokemonDetails.svelte -->

<script>
  import { onMount } from 'svelte';
  import { getPokemonDetails } from '../pokemonApi';

  let pokemonId = '';
  /**
   * @type {{ name: any; id: any; } | null}
   */
  let pokemonDetails = null;

  const getPokemon = async () => {
    try {
      console.log('Fetching details for Pokemon ID:', pokemonId);
      // Roep de getPokemonDetails-functie aan om details van de geselecteerde Pokémon op te halen
      pokemonDetails = await getPokemonDetails(pokemonId);
      console.log('Received Pokemon details:', pokemonDetails);
    } catch (error) {
      console.error('Fout bij het ophalen van Pokémon-details:', error);
    }
  };

  onMount(() => {
    // Roep getPokemon functie aan wanneer het component is gemount
    getPokemon();
  });
</script>

<main>
  <h1>Pokemon-details</h1>
  <label for="pokemonId">Voer Pokemon-ID in:</label>
  <input type="text" bind:value={pokemonId} id="pokemonId" />
  <button on:click={getPokemon}>Haal Pokemon-details op</button>

  {#if pokemonDetails}
    <div>
      <h2>{pokemonDetails.name}</h2>
      <p>ID: {pokemonDetails.id}</p>
      <!-- Voeg hier andere details toe -->
    </div>
  {:else}
    <p>Geen Pokémon-details beschikbaar.</p>
  {/if}
</main>

<style>
  /* Voeg hier eventuele CSS-stijlen toe voor opmaak */
</style>
