<!-- src/routes/index.svelte -->

<script>
    import PokemonList from './PokemonList.svelte';
  </script>
  
  <main>
    <h1>Welkom op de Pokémon-pagina</h1>
    <!-- Voeg hier andere inhoud toe -->
    <PokemonList />
  </main>
  