<!-- PokemonList.svelte -->

<script lang="ts">
  import { onMount } from 'svelte';
  import { getAllPokemons } from '../pokemonApi';

  let pokemonList: { id: string, name: string }[] = [];
  let searchQuery = '';
  let originalPokemonList: { id: string, name: string }[] = [];

  onMount(async () => {
    try {
      // Roep de getAllPokemons-functie aan om de lijst met Pokémon op te halen
      originalPokemonList = await getAllPokemons();
      pokemonList = originalPokemonList;
    } catch (error) {
      console.error('Fout bij het ophalen van Pokémon-lijst:', error);
    }
  });

  const searchPokemon = () => {
    // Filter de lijst met Pokémon op basis van de ingevoerde zoekquery (naam van de Pokémon)
    if (searchQuery.trim() !== '') {
      pokemonList = originalPokemonList.filter(pokemon => pokemon.name.toLowerCase().includes(searchQuery.toLowerCase()));
    } else {
      // Als de zoekquery leeg is, toon de volledige lijst
      pokemonList = originalPokemonList;
    }
  };
</script>

<main>
  <h1>Lijst met Pokemon</h1>

  <!-- Voeg hier het invoerveld toe -->
  <label for="search">Zoek een Pokemon:</label>
  <input type="text" bind:value={searchQuery} id="search" />
  <button on:click={searchPokemon}>Zoeken</button>

  {#if pokemonList.length > 0}
    <ul>
      {#each pokemonList as pokemon (pokemon.id)}
        <li>{pokemon.name}</li>
      {/each}
    </ul>
  {:else}
    <p>Geen Pokemon gevonden.</p>
  {/if}
</main>

<style>
  /* Voeg hier eventuele CSS-stijlen toe voor opmaak */
</style>
